package bangun2D;

public abstract class BangunDatar {
    
    public abstract double getLuas();
    
    public abstract double getKeliling();
    
    public abstract String toString();
}
