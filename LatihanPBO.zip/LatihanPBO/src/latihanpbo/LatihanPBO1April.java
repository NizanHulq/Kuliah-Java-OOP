package latihanpbo;

import bangun3D.PrismaSegitiga;

public class LatihanPBO1April {
    public static void main(String[] args) {
        PrismaSegitiga prisma1 = new PrismaSegitiga(null, 10);
        System.out.println(prisma1);
        System.out.println(prisma1.getVolume());
        System.out.println(prisma1.getDetailAlas());
        System.out.println("======================");
    }
    
}
